Thank u bruno ♥

لا أتقن أي لغة برمجة لذا ان اخطأت فلا عذر لي لا نزال في طريق التعلم ... رغم ذلك أهوى التعديل على السكريبتات ههه ♥ اتمنى انك استفذت 
اي ملاحطة او مساعدة انا هنا

https://instagram.com/abdsamad___75

get session code from this link

https://replit.com/@bobiztestbot/bobiza-qrcode
 
 
